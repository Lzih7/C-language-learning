# C-language-learning
# Markdown 学习笔记

Markdown 是一种轻量级的标记语言，用于编写格式化的文档。以下是 Markdown 的一些基本用法。

---

## 1. 标题

Markdown 使用 `#` 来创建标题。根据 `#` 的数量不同，可以创建不同级别的标题。

```markdown
# 一级标题
## 二级标题
### 三级标题
