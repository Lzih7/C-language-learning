#ifndef __LIGHTING_H
#define __LIGHTING_H

void Lighting_Init(void);
uint8_t Lighting_Get(void);

#endif
