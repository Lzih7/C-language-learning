#ifndef __USART_H
#define __USART_H

void USART1_CFG(void);

#endif
